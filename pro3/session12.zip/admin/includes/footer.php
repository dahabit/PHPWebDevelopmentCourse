                </div>
                <!-- // #main -->
                
                <div class="clear"></div>
            </div>
            <!-- // #container -->
        </div>	
        <!-- // #containerHolder -->
        
        <p id="footer">جميع الحقوق محفوظة لـ <a href="http://vbegy.info/">vbegy</a></p>
    </div>
    <!-- // #wrapper -->
</body>
</html>