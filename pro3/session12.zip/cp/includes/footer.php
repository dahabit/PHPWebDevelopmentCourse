</div>
            <div id="sidebar">
  				<ul>
                	<li><h3><a href="index.php" class="house">الرئيسية</a></h3>
                        <ul>
                        	<li><a href="logout.php" class="report">تسجيل الخروج</a></li>
                    		
                        </ul>
                    </li>
                    <li><h3><a href="#" class="folder_table">التحكم في المستخدمين</a></h3>
          				<ul>
                        	<li><a href="adduser.php" class="addorder">إضافة مستخدم</a></li>
                         
                        </ul>
                    </li>
                    <li><h3><a href="#" class="manage">التحكم في الأقسام</a></h3>
          				<ul>
                            <li><a href="addcat.php" class="manage_page">إضافة قسم</a></li>
                            <li><a href="vactivecats.php" class="cart">عرض الأقسام المفعلة</a></li>
                            <li><a href="vunactivecats.php" class="folder">  عرض الأقسام الغير مفعلة </a></li>
            				
                        </ul>
                    </li>
                  <li><h3><a href="#" class="user">التحكم في المنتجات</a></h3>
          				<ul>
                            <li><a href="addproduct.php" class="useradd">إضافة منتج</a></li>
                            <li><a href="viewaproduct.php" class="group">عرض المنتجات المفعلة</a></li>
            				
                        </ul>
                    </li>
				</ul>       
          </div>
      </div>
        <div id="footer">
        <div id="credits">
   		Template by <a href="http://www.bloganje.com">Bloganje</a>
        </div>
        <div id="styleswitcher">
            <ul>
                <li><a href="javascript: document.cookie='theme='; window.location.reload();" title="Default" id="defswitch">d</a></li>
                <li><a href="javascript: document.cookie='theme=1'; window.location.reload();" title="Blue" id="blueswitch">b</a></li>
                <li><a href="javascript: document.cookie='theme=2'; window.location.reload();" title="Green" id="greenswitch">g</a></li>
                <li><a href="javascript: document.cookie='theme=3'; window.location.reload();" title="Brown" id="brownswitch">b</a></li>
                <li><a href="javascript: document.cookie='theme=4'; window.location.reload();" title="Mix" id="mixswitch">m</a></li>
                <li><a href="javascript: document.cookie='theme=5'; window.location.reload();" title="Mix" id="defswitch">m</a></li>
            </ul>
        </div><br />

        </div>
</div>
</body>
</html>
