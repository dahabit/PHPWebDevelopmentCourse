<br>
<br>

<div align="center">
	<table " width="180" CELLPADDING=5 CELLSPACING=5 dir="rtl" >
		<tr>
			<td valign="top" height="100%" align="center" id="menuadminh">
خيارات عامة</td>
		</tr>
		<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="index.php">الرئيسية</a></td>
		</tr>	
			<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="logout.php">تسجيل الخروج</a></td>
		</tr>		
	</table>
</div>
<br>
<div align="center">
	<table " width="180" CELLPADDING=5 CELLSPACING=5 dir="rtl" >
		
		
		<tr>
			<td valign="top" height="100%" align="center" id="menuadminh">
التحكم في المستخدمين</td>
		</tr>
		<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="adduser.php" > أضف مستخدم جديد</a>
			</td>
		</tr>
	
		
	
	</table>
</div>
<br>
<div align="center">
	<table " width="180" CELLPADDING=5 CELLSPACING=5 dir="rtl" >
		
		
		<tr>
			<td valign="top" height="100%" align="center" id="menuadminh">
التحكم في الصفحات</td>
		</tr>
		<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="addpage.php" > أضف صفحة جديدة</a>
			</td>
		</tr>
	<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="viewactivepages.php" > عرض الصفحات المفعلة</a>
			</td>
			
		</tr>
		
	<tr>
	<td valign="top" height="100%" id="menuadmin">
<a href="viewunactivepages.php" > عرض الصفحات غير المفعلة</a>
			</td>
	</tr>
	</table>
</div>
<br>

<div align="center">
	<table " width="180" CELLPADDING=5 CELLSPACING=5 dir="rtl" >
		
		
		<tr>
			<td valign="top" height="100%" align="center" id="menuadminh">
القائمة العلوية</td>
		</tr>
		<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="addtopmenu.php" > أضف قائمة جديدة</a>
			</td>
		</tr>
	<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="viewactivemenu.php" > عرض القوائم المفعلة</a>
			</td>
		</tr>
		
	
	</table>
</div>
<br>



<div align="center">
	<table " width="180" CELLPADDING=5 CELLSPACING=5 dir="rtl" >
		
		
		<tr>
			<td valign="top" height="100%" align="center" id="menuadminh">
القائمة اليمنى</td>
		</tr>
		<tr>
			
			<td valign="top" height="100%" id="menuadmin">
<a href="addrightmenu.php" > أضف قائمة جديدة</a>
			</td>
		</tr>
	
		
	
	</table>
</div>
<br>


